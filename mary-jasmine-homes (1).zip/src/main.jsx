import React from "react";
import ReactDOM from "react-dom/client";
import MaryJasmineWebsite from "./MaryJasmineWebsite";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <MaryJasmineWebsite />
  </React.StrictMode>
);
